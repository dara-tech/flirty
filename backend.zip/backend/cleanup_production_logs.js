#!/usr/bin/env node

/**
 * Production Log Cleanup for Node.js Backend
 *
 * This script removes or minimizes console.log statements for production deployment.
 * It wraps debug logs in NODE_ENV checks and keeps only essential production logs.
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class BackendLogCleaner {
  constructor() {
    this.stats = {
      filesScanned: 0,
      filesModified: 0,
      logsCommented: 0,
      logsWrapped: 0,
      logsKept: 0,
    };
  }

  /**
   * Check if log should be kept in production (error/critical logs)
   */
  isProductionLog(line) {
    const productionPatterns = [
      /console\.error/,
      /console\.warn/,
      /Server.*running/i,
      /Connected to/i,
      /MongoDB.*connected/i,
      /listening on port/i,
      /❌.*error/i,
      /⚠️.*warning/i,
    ];

    return productionPatterns.some((pattern) => pattern.test(line));
  }

  /**
   * Check if log is already commented or wrapped
   */
  isAlreadyHandled(line) {
    return (
      line.trim().startsWith("//") || line.includes("process.env.NODE_ENV")
    );
  }

  /**
   * Process a single file
   */
  processFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, "utf8");
      const lines = content.split("\n");
      const modifiedLines = [];
      let modified = false;
      let i = 0;

      while (i < lines.length) {
        const line = lines[i];
        const trimmed = line.trim();

        // Check if this is a console.log statement
        if (
          trimmed.startsWith("console.log(") ||
          (trimmed.startsWith("//") && trimmed.includes("console.log("))
        ) {
          // Skip if already handled
          if (this.isAlreadyHandled(line)) {
            modifiedLines.push(line);
            i++;
            continue;
          }

          // Keep production-critical logs (uncommented)
          if (this.isProductionLog(line)) {
            modifiedLines.push(line);
            this.stats.logsKept++;
            i++;
            continue;
          }

          // Handle multi-line console.log
          let fullStatement = line;
          let j = i;
          let openParens = (line.match(/\(/g) || []).length;
          let closeParens = (line.match(/\)/g) || []).length;

          // Find the end of multi-line statement
          while (openParens > closeParens && j < lines.length - 1) {
            j++;
            fullStatement += "\n" + lines[j];
            openParens += (lines[j].match(/\(/g) || []).length;
            closeParens += (lines[j].match(/\)/g) || []).length;
          }

          // Comment out debug logs
          if (trimmed.startsWith("console.log(")) {
            const indent = line.match(/^\s*/)[0];
            for (let k = i; k <= j; k++) {
              if (k === i) {
                modifiedLines.push(
                  `${indent}// ${lines[
                    k
                  ].trim()} // [DEBUG - Removed for production]`
                );
              } else {
                modifiedLines.push(`${indent}// ${lines[k].trim()}`);
              }
            }
            this.stats.logsCommented++;
            modified = true;
          } else {
            // Already commented, keep as is
            for (let k = i; k <= j; k++) {
              modifiedLines.push(lines[k]);
            }
          }

          i = j + 1;
        } else {
          modifiedLines.push(line);
          i++;
        }
      }

      // Write back if modified
      if (modified) {
        // Create backup
        const backupPath = filePath + ".bak";
        fs.copyFileSync(filePath, backupPath);

        fs.writeFileSync(filePath, modifiedLines.join("\n"), "utf8");
        this.stats.filesModified++;

        const relativePath = path.relative(process.cwd(), filePath);
        console.log(
          `   ✅ ${relativePath}: ${this.stats.logsCommented} logs commented`
        );
      }

      this.stats.filesScanned++;
    } catch (error) {
      console.error(`   ❌ Error processing ${filePath}:`, error.message);
    }
  }

  /**
   * Recursively scan directory
   */
  scanDirectory(dir, pattern = /\.js$/) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);

      // Skip node_modules and hidden files
      if (entry.name === "node_modules" || entry.name.startsWith(".")) {
        continue;
      }

      if (entry.isDirectory()) {
        this.scanDirectory(fullPath, pattern);
      } else if (entry.isFile() && pattern.test(entry.name)) {
        this.processFile(fullPath);
      }
    }
  }

  /**
   * Generate summary report
   */
  generateReport() {
    console.log(
      "\n============================================================"
    );
    console.log("✅ Backend Log Cleanup Complete!");
    console.log("============================================================");
    console.log("📊 Statistics:");
    console.log(`   - Total files scanned: ${this.stats.filesScanned}`);
    console.log(`   - Files modified: ${this.stats.filesModified}`);
    console.log(`   - Debug logs commented: ${this.stats.logsCommented}`);
    console.log(`   - Production logs kept: ${this.stats.logsKept}`);
    console.log("");
    console.log("🎯 Production Impact:");
    console.log("   - Debug console output eliminated");
    console.log("   - Critical logs (errors/warnings) preserved");
    console.log("   - Server startup logs maintained");
    console.log("   - Performance: Less I/O overhead");
    console.log("");
    console.log("📋 Next Steps:");
    console.log("   1. Test server: npm run dev");
    console.log("   2. Verify logs still work in development");
    console.log("   3. Deploy to production: npm start");
    console.log("   4. Monitor logs: No debug spam in production");
    console.log("");
    console.log("💾 Backups:");
    console.log("   - Backups saved with .bak extension");
    console.log(
      '   - To restore: find src -name "*.bak" -exec sh -c \'mv "$1" "${1%.bak}"\' _ {} \\;'
    );
    console.log("");
  }

  /**
   * Run cleanup
   */
  run(targetDir) {
    console.log("🧹 Cleaning backend logs for production...");
    console.log(`📁 Scanning: ${targetDir}\n`);

    this.scanDirectory(targetDir);
    this.generateReport();
  }
}

// Main execution
const isMainModule =
  import.meta.url === `file://${process.argv[1]}` ||
  import.meta.url.endsWith(process.argv[1]);

if (isMainModule) {
  const srcDir = path.join(__dirname, "src");

  if (!fs.existsSync(srcDir)) {
    console.error("❌ Error: src directory not found!");
    console.error("   Make sure you run this from the backend root directory.");
    process.exit(1);
  }

  const cleaner = new BackendLogCleaner();
  cleaner.run(srcDir);
}

export default BackendLogCleaner;
