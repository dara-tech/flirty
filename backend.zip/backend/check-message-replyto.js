import mongoose from "mongoose";
import { config } from "dotenv";
import Message from "./src/model/message.model.js";

config();

// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// Check specific message
const messageId = "6957b21e3c5b6df9988c135e";

async function checkMessage() {
  try {
    const message = await Message.findById(messageId);

    if (!message) {
      console.log("❌ Message not found");
      process.exit(1);
    }

    console.log("\n📝 Message Details:");
    console.log("   ├─ ID:", message._id.toString());
    console.log("   ├─ Text:", message.text);
    console.log("   ├─ Has replyTo:", !!message.replyTo);
    console.log("   ├─ replyTo value:", message.replyTo);
    console.log("   ├─ replyTo type:", typeof message.replyTo);
    console.log("   ├─ Created:", message.createdAt);
    console.log("   └─ Updated:", message.updatedAt);

    if (message.replyTo) {
      console.log("\n🔗 Reply Reference:");
      console.log("   ├─ Reply To ID:", message.replyTo.toString());

      const repliedMessage = await Message.findById(message.replyTo);
      if (repliedMessage) {
        console.log("   ├─ Replied Message Text:", repliedMessage.text);
        console.log("   ├─ Replied Message Created:", repliedMessage.createdAt);
        console.log("   ├─ Has Image:", !!repliedMessage.image);
        console.log("   ├─ Has Video:", !!repliedMessage.video);
        console.log("   ├─ Has Audio:", !!repliedMessage.audio);
        console.log("   └─ Has File:", !!repliedMessage.file);
      } else {
        console.log("   └─ ⚠️ Replied message not found (orphaned reference)");
      }
    }

    console.log("\n✅ Check complete");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error);
    process.exit(1);
  }
}

checkMessage();
